import java.util.*;

/**
 * GB Manufacturing - Equipment Checkout System (ECS)
 * Console Version - IntelliJ Ready
 *
 * Features:
 *  - Employee and Equipment management
 *  - Checkout and return tracking
 *  - Skill-based restrictions
 *  - Randomized test mode (--test)
 *
 * Author: Michael Wright
 * Prepared for: GB Manufacturing Project
 * Date: October 29, 2025
 */

class Employee {
    private final int id;
    private final String name;
    private final Set<String> skills;
    private final List<Equipment> checkedOutEquipment = new ArrayList<>();

    public Employee(int id, String name, Set<String> skills) {
        this.id = id;
        this.name = name;
        this.skills = skills;
    }

    public int getId() { return id; }

    public String getName() { return name; }

    public Set<String> getSkills() { return skills; }

    public List<Equipment> getCheckedOutEquipment() { return checkedOutEquipment; }

    public boolean canUse(Equipment e) {
        return e.getRequiredSkill() == null || skills.contains(e.getRequiredSkill());
    }

    public void checkout(Equipment e) {
        checkedOutEquipment.add(e);
    }

    public void returnEquipment(Equipment e) {
        checkedOutEquipment.remove(e);
    }

    @Override
    public String toString() {
        return String.format("%d - %s (Skills: %s)", id, name, skills);
    }
}

class Equipment {
    private final int id;
    private final String name;
    private final String requiredSkill;
    private boolean isCheckedOut;
    private Employee currentHolder;
    private Employee lastHolder;

    public Equipment(int id, String name, String requiredSkill) {
        this.id = id;
        this.name = name;
        this.requiredSkill = requiredSkill;
        this.isCheckedOut = false;
    }

    public int getId() { return id; }

    public String getName() { return name; }

    public String getRequiredSkill() { return requiredSkill; }

    public boolean isCheckedOut() { return isCheckedOut; }

    public Employee getCurrentHolder() { return currentHolder; }

    public Employee getLastHolder() { return lastHolder; }

    public void checkout(Employee e) {
        this.isCheckedOut = true;
        this.currentHolder = e;
        this.lastHolder = e;
    }

    public void checkin() {
        this.isCheckedOut = false;
        this.currentHolder = null;
    }

    @Override
    public String toString() {
        String status = isCheckedOut
                ? "Checked out by " + currentHolder.getName()
                : "Available";
        return String.format("[%d] %s (%s) - %s", id, name,
                requiredSkill == null ? "No skill required" : "Requires: " + requiredSkill, status);
    }
}

class InMemoryDatabase {
    private final Map<Integer, Employee> employees = new HashMap<>();
    private final Map<Integer, Equipment> equipmentList = new HashMap<>();

    public Map<Integer, Employee> getEmployees() { return employees; }

    public Map<Integer, Equipment> getEquipmentList() { return equipmentList; }

    public void seedTestData() {
        employees.put(1, new Employee(1, "John Carter", Set.of("electrician", "welder")));
        employees.put(2, new Employee(2, "Maria Lopez", Set.of("plumber", "carpenter")));
        employees.put(3, new Employee(3, "Alex Smith", Set.of("painter")));
        employees.put(4, new Employee(4, "Sarah Johnson", Set.of("carpenter", "electrician")));

        equipmentList.put(100, new Equipment(100, "Welding Torch", "welder"));
        equipmentList.put(101, new Equipment(101, "Electric Drill", "electrician"));
        equipmentList.put(102, new Equipment(102, "Hammer", null));
        equipmentList.put(103, new Equipment(103, "Pipe Wrench", "plumber"));
        equipmentList.put(104, new Equipment(104, "Paint Sprayer", "painter"));
    }
}

public class ECSConsole {
    private static final Scanner scanner = new Scanner(System.in);
    private static final InMemoryDatabase db = new InMemoryDatabase();

    public static void main(String[] args) {
        db.seedTestData();

        if (args.length > 0 && args[0].equalsIgnoreCase("--test")) {
            runRandomTestMode();
            return;
        }

        showMenu();
    }

    private static void showMenu() {
        while (true) {
            System.out.println("\n=== GB Manufacturing Equipment Checkout System ===");
            System.out.println("1. View Employees");
            System.out.println("2. View Equipment");
            System.out.println("3. Checkout Equipment");
            System.out.println("4. Return Equipment");
            System.out.println("5. View Employee Equipment");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> listEmployees();
                case "2" -> listEquipment();
                case "3" -> checkoutEquipment();
                case "4" -> returnEquipment();
                case "5" -> viewEmployeeEquipment();
                case "6" -> {
                    System.out.println("Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void listEmployees() {
        System.out.println("\n--- Employees ---");
        db.getEmployees().values().forEach(System.out::println);
    }

    private static void listEquipment() {
        System.out.println("\n--- Equipment ---");
        db.getEquipmentList().values().forEach(System.out::println);
    }

    private static void checkoutEquipment() {
        listEmployees();
        System.out.print("\nEnter employee ID: ");
        int empId = Integer.parseInt(scanner.nextLine());
        Employee emp = db.getEmployees().get(empId);
        if (emp == null) {
            System.out.println("Invalid employee ID.");
            return;
        }

        listEquipment();
        System.out.print("\nEnter equipment ID to checkout: ");
        int eqId = Integer.parseInt(scanner.nextLine());
        Equipment eq = db.getEquipmentList().get(eqId);
        if (eq == null) {
            System.out.println("Invalid equipment ID.");
            return;
        }

        if (eq.isCheckedOut()) {
            System.out.println("That equipment is already checked out!");
            return;
        }

        if (!emp.canUse(eq)) {
            System.out.println("This employee does not have the required skill to use that equipment.");
            return;
        }

        eq.checkout(emp);
        emp.checkout(eq);
        System.out.println("✅ " + emp.getName() + " successfully checked out " + eq.getName());
    }

    private static void returnEquipment() {
        listEquipment();
        System.out.print("\nEnter equipment ID to return: ");
        int eqId = Integer.parseInt(scanner.nextLine());
        Equipment eq = db.getEquipmentList().get(eqId);

        if (eq == null || !eq.isCheckedOut()) {
            System.out.println("That equipment is not currently checked out.");
            return;
        }

        Employee emp = eq.getCurrentHolder();
        eq.checkin();
        emp.returnEquipment(eq);
        System.out.println("✅ " + eq.getName() + " returned successfully by " + emp.getName());
    }

    private static void viewEmployeeEquipment() {
        listEmployees();
        System.out.print("\nEnter employee ID to view their equipment: ");
        int empId = Integer.parseInt(scanner.nextLine());
        Employee emp = db.getEmployees().get(empId);

        if (emp == null) {
            System.out.println("Invalid employee ID.");
            return;
        }

        System.out.println("\n--- Equipment currently checked out by " + emp.getName() + " ---");
        if (emp.getCheckedOutEquipment().isEmpty()) {
            System.out.println("None.");
        } else {
            emp.getCheckedOutEquipment().forEach(System.out::println);
        }
    }

    // --- TEST MODE ---
    private static void runRandomTestMode() {
        System.out.println("Running ECS Test Mode...");

        Random rand = new Random();
        List<Employee> employees = new ArrayList<>(db.getEmployees().values());
        List<Equipment> equipment = new ArrayList<>(db.getEquipmentList().values());

        // Randomly checkout and return equipment
        for (int i = 0; i < 10; i++) {
            Employee emp = employees.get(rand.nextInt(employees.size()));
            Equipment eq = equipment.get(rand.nextInt(equipment.size()));

            if (!eq.isCheckedOut() && emp.canUse(eq)) {
                eq.checkout(emp);
                emp.checkout(eq);
                System.out.printf("Test: %s checked out %s%n", emp.getName(), eq.getName());
            } else if (eq.isCheckedOut()) {
                eq.getCurrentHolder().returnEquipment(eq);
                eq.checkin();
                System.out.printf("Test: %s returned %s%n", emp.getName(), eq.getName());
            }
        }

        System.out.println("\n--- Test Summary ---");
        listEquipment();
        System.out.println("\nTest Mode complete.");
    }
}
